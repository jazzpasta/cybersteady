---
ticker: "3402"
company: "東レ / Toray Industries"
meeting_date: ""
date_confidence: "unknown"
date_note: "日付の記載なし。内容が [[Meetings/Corporate/3402 東レ 面談Q&A 2026-08-19]] とほぼ同一論点（中東 ▲130 億の上下期折半、原料 Time Lag、上期 +140 億の三要因）で、同じ 2026-08-19 面談の別メモの可能性が高い——**要確認**。"
type: "management-meeting"
quarter: "FY27/3 1Q"
tags:
  - equity/japan
  - sector/chemicals
  - theme/carbon-fiber
  - meeting-note
  - date-todo
summary: >-
  1Q 上振れ要因の短記。期初 1,600 億は中東 ▲130 億（上期 65 / 下期 65）を織り込んだ数字で、悪い部分を Minimize でき上振れ。上期修正 140 億の内訳は 価格転嫁の進捗 ＋ 原料上昇前在庫の評価益 30–40 億（2Q で消える）＋ 数量差（成長事業と先行発注）。**MLCC 離型フィルム**が 1Q 非常に好調（High End シェア 50%、前年比 2–3 割増、昨年 Capacity を 1.6 倍化、PET フィルム全体より MLCC 向けがタイト）。**炭素繊維**は価格ネガティブ（原燃料転嫁の遅れ・LTA 長期契約）だが航空宇宙の伸びが高い：787 出荷は去年 1Q 月 5–6 機 → 今年 1Q 月 9 機（ピークは月 14 機モデル）、年内 10 機へ。Capacity Ramp は 2Q から（CFE/TAK/CMA）で今年フル稼働できず 2Q 利益は弱め。競合は Hexcel。下期の中東 130 億は「今の見通しではない」。
---

1Q 期初　1600億事業利益見通し、中東130億減益要因を見込んで。悪い部分Minimize、いい効果部分出ている。上振れている。

130億うち上期半分６５億、下期６５億。上期Raw Material Time Lagあると前提で。下期は値上げアリに対して需要減を見ていた。

上期情報修正１４bn、幾つの要因ある、価格転嫁想定より進んで、Negative　Impact少なかった。
Rat Mat 上がる前買ってた在庫３０−４０億のPositive Impactありました。

数量差は上振れ、成長事業伸びたか、先高感ある、先行発注一部もあった。在庫評価益２Qなくなる、先行需要切り離すできない、上期飲みの調整。

Segment
Performance Chemical 最も在庫影響受けます。
２Q以降は弱くなる。５.6bn most. Resin is front loaded. Price hike could be faster than cost up. 加工度低い樹脂と原料が反映されやすい。

フィルムはResinさらに加工したもの、増益はばは成長事業。

MLCCの製造工程で使うリリースフィルム、今回１Q非常に好調。High End、５０％　Share、歩留影響与える製造工程。１Q ２−３割増加達成Revy・y。２Q囲碁も継続。価格について、適正のコストアップに応じた、需給バランスでタイト。韓国も拠点もあり、SE MCO 中国も出している。

MLCC High End Capacity Last Year 増産設備、１.６倍にした。PET FILM全体８〜９割、MLCCよりTight.

２Hも。今の見通しは１３０億はない。物価格差がて経済悪くなる可能性もある。


炭素繊維
価格ネガティブ。？売上は航空宇宙伸び率高い。
７８７出荷は大きく戻った。去年1 Q 月５−６機、今年１Q９機。Peakは月１４機モデル。コロナは０で、少しつづ。今年中１０機上がる。Build Rate 上がる。一方で、価格Negativeは原燃料価格転嫁が遅れた。長期契約顧客が多い。LTA 契約ベース。

昨年SPLC在庫貯めていた、今Tier１Restocking、
Boeing 生産と弊社TGある、半年前出荷している。年末１０機に対して、弊社の生産量が含めている。

エンジン調達リスク、ただし現状は弊社の生産をおさえていない。

Competitor?
Hexel is Toray is major competiror. フォーマソーべ 

炭素繊維
産業も悪くなかった、Inentory Adj終わり、アジアも需給回復しつつ。

Capacity Ramp ramp from 2Q, CFE TAK CMA。今年フルCapcity走れないので、２Q利益は弱め、２年後中継はフルの状態持っていく。

機能化成品のGap？
過小評価していると言われたこともあり、過去のMTP一回Missしたし、結果を示すしかない。



