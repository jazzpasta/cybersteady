from pathlib import Path
import pandas as pd, numpy as np, io, json, hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
R=Path('/Users/wenjun/Downloads/Nemesis/Almighty/research/smc_relval'); O=R/'outputs/PM_brief_20260914';O.mkdir(exist_ok=True)
font=FontProperties(fname='/System/Library/Fonts/Supplemental/Arial Unicode.ttf');plt.rcParams.update({'font.family':font.get_name(),'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'path','axes.unicode_minus':False})
blue='#2264ac'; green='#168477'; red='#b74641';gray='#718096'
def svg(fig,name):
 b=io.StringIO();fig.savefig(b,format='svg',bbox_inches='tight',facecolor='white');fig.savefig(O/(name+'.png'),dpi=150,bbox_inches='tight');plt.close(fig);return b.getvalue()[b.getvalue().index('<svg'):]
def card(n,title,lines,chart,note,source):
 return f'<article><div class="num">{n:02d} / 06</div><h2>{title}</h2><div class="thesis">'+''.join('<div>'+x+'</div>' for x in lines)+f'</div><div class="chart">{chart}</div><p class="note">{note}</p><footer>{source}</footer></article>'

def table_plot(values, rows, cols, title, name, signed=True, neutral_rows=()):
 from matplotlib.colors import TwoSlopeNorm
 arr=np.asarray(values,dtype=float)
 fig,ax=plt.subplots(figsize=(13,max(2.8,.39*len(rows)+1.15)))
 colors=np.zeros((*arr.shape,4));cmap=plt.get_cmap('BrBG'); norm=TwoSlopeNorm(vmin=-6,vcenter=0,vmax=6)
 for i in range(len(rows)):
  for j in range(len(cols)):
   colors[i,j]=(.94,.96,.98,1) if i in neutral_rows or not signed else cmap(norm(np.clip(arr[i,j],-6,6)))
 ax.imshow(colors,aspect='auto');ax.set_xticks(range(len(cols)),cols,fontsize=10);ax.xaxis.tick_top();ax.tick_params(length=0,pad=8);ax.set_yticks(range(len(rows)),rows,fontsize=10)
 for i in range(len(rows)):
  for j in range(len(cols)):
   v=arr[i,j];txt=(f'{v:+.2f}' if signed and i not in neutral_rows else f'{v:.2f}' if signed else f'{v:,.0f}')
   ax.text(j,i,txt,ha='center',va='center',fontsize=10,color='white' if signed and i not in neutral_rows and abs(v)>3.5 else '#142537')
 ax.set_xticks(np.arange(-.5,len(cols),1),minor=True);ax.set_yticks(np.arange(-.5,len(rows),1),minor=True);ax.grid(which='minor',color='white',lw=2);ax.tick_params(which='minor',length=0)
 for spine in ax.spines.values():spine.set_visible(False)
 ax.set_title(title,pad=35,loc='left',fontsize=12,fontweight='bold');fig.tight_layout()
 return '<div class="historyplot">'+svg(fig,name)+'</div>'

summary=R/'SMC_Research_Summary_20260914.md'
source_summary='<a href="../../SMC_Research_Summary_20260914.md">已核研究汇总（2026-09-14）</a>'
q=pd.read_csv(R/'earnings_review/quarterly_financials.csv').tail(10); bridge=pd.read_csv(R/'earnings_review/quarterly_analysis.csv');ret=pd.read_csv(R/'earnings_review/SMC_shareholder_returns_10Y.csv').tail(7)
d=pd.read_csv(R/'earnings_review/近5Q_七行业长表_v2.csv');a=d.groupby(['季度末','行业'])['行业收入估算_亿日元'].sum().unstack();start=a.loc['2025-06-30'];end=a.loc['2026-06-30'];order=end.sort_values().index;yoy=(end/start-1)*100
ordered=['半导体','电机','汽车','机械','食品','医疗','其他']; dates=[pd.Timestamp(z).strftime('%Y/%m') for z in a.index]
fig,axes=plt.subplots(1,2,figsize=(12,3.5),gridspec_kw={'width_ratios':[1.4,1]});colors=['#2264ac','#7e61a2','#168477','#d78832','#cc6262','#688fa6','#a3adba']
for k,c in zip(ordered,colors):axes[0].plot(range(5),a[k],marker='o',lw=2,label=k,color=c)
axes[0].set_xticks(range(5),dates,rotation=20);axes[0].set_ylabel('收入估算｜亿日元');axes[0].set_ylim(bottom=0);axes[0].legend(ncol=4,fontsize=9,loc='upper left');axes[0].grid(axis='y',alpha=.15)
axes[1].barh(ordered[::-1],yoy[ordered[::-1]],color=colors[::-1]);axes[1].set_xlabel('最新季同比增长｜%');axes[1].set_xlim(0,100)
for i,v in enumerate(yoy[ordered[::-1]]):axes[1].text(v+1,i,f'{v:.1f}%',va='center',fontsize=10)
fig.tight_layout();growth_chart=svg(fig,'01_downstream_trend_v2')
growth_table=table_plot(a[ordered].T.values,ordered,dates,'各下游连续5季收入估算｜亿日元','01_downstream_history_v2',signed=False)
qoq=a[ordered].pct_change().iloc[1:]*100
growth_qoq=table_plot(qoq.T.values,ordered,dates[1:],'环比成长｜%（颜色仅表示正负，非份额变化）','01_downstream_qoq_v2')
covered=end.sum();prior=start.sum(); semigrowth=yoy['半导体'];semi=end['半导体']; semicontrib=(end['半导体']-start['半导体'])/(covered-prior)*100
cards=[]
cards.append(card(1,'下游：连续5季规模与成长',[f'● 半导体由{start["半导体"]:,.0f}亿增至{semi:,.0f}亿，最新季同比{semigrowth:.0f}%，贡献已覆盖地区增收约{semicontrib:.0f}%。','趋势图＋季度收入表＋环比表，区分复苏的时间与强弱；增长不等于份额提升。'],growth_chart+growth_table+growth_qoq,f'2025年4–6月至2026年4–6月，横轴为季度末。五个主要经营地区，最新覆盖集团收入{covered/2709.87:.1%}；各季地区收入×当地行业占比估算，取整占比会影响增速。更早同口径七行业数据不足，故只有最新季可算同比；首季环比不填零。电机＝电气／电子。',source_summary+' · <a href="../../earnings_review/近5Q_七行业长表_v2.csv">5季行业原表</a>'))
fig,axes=plt.subplots(1,2,figsize=(10,3.1));x=np.arange(len(q));labels=pd.to_datetime(q.CurPerEn).dt.strftime('%y/%m')
for ax,col,title,c in [(axes[0],'gpm','毛利率 GPM',blue),(axes[1],'opm','营业利润率 OPM',green)]:
 ax.plot(x,q[col],'-o',color=c,lw=2);ax.set_xticks(x,labels,rotation=45);ax.set_title(title);ax.set_ylabel('%');ax.grid(axis='y',alpha=.15);ax.text(x[-1],q[col].iloc[-1]+.4,f'{q[col].iloc[-1]:.2f}%',ha='right',color=c,fontweight='bold')
fig.tight_layout()
cards.append(card(2,'利润率：恢复已发生，尚未回到历史高位',['● 支持修复：2026年4–6月GPM 46.84%、OPM 27.30%，同比各升2.55／5.09个百分点。','△ 限制：这是报告利润率，含库存评价及关税退款影响；不能直接当持续性核心利润率。'],svg(fig,'02_margins'),'两图纵轴独立、均非零起点；单季财报实际。2023年3月止全年GPM／OPM为51.06%／31.31%，仅作历史参照。',source_summary+' · <a href="../../earnings_review/quarterly_financials.csv">季度财务</a>'))
b=bridge.iloc[-1];labs=['销量','净售价','汇率','库存评价','制造等','销售管理费','舍入差'];vals=[b.volume,b.price,b.fx,b.inventory,b.manufacturing_other,b.sga,b.op_residual]
periods=pd.to_datetime(bridge.period).dt.strftime('%y/%m').tolist()
gpm_cols=['gpm','gpm_yoy','volume_gpm_pp','price_gpm_pp','inventory_gpm_pp','gpm_other_pp']
gpm_rows=['报告GPM（%）','GPM同比变化','销量桥换算*','净售价','库存评价','其余影响（残差）']
gpm_plot=table_plot(bridge[gpm_cols].T.values,gpm_rows,periods,'GPM历史归因｜2024年1–3月至2026年4–6月；贡献单位：百分点','03_gpm_history_v2',neutral_rows=(0,))
opm_cols=['opm','opm_yoy','volume_opm_pp','price_opm_pp','fx_opm_pp','inventory_opm_pp','manufacturing_other_opm_pp','sga_opm_pp','tariff_opm_pp','scope_opm_pp','opm_residual_pp']
opm_rows=['报告OPM（%）','OPM同比变化','销量','净售价','汇率','库存评价','制造／材料／其他','销售管理费','关税（单列项）','并表范围','桥接残差']
opm_plot=table_plot(bridge[opm_cols].T.values,opm_rows,periods,'OPM历史归因｜贡献单位：百分点；各贡献相加＝OPM同比变化','03_opm_history_v2',neutral_rows=(0,))
assert np.max(np.abs(bridge[gpm_cols[2:]].sum(axis=1)-bridge.gpm_yoy))<.00001
assert np.max(np.abs(bridge[opm_cols[2:]].sum(axis=1)-bridge.opm_yoy))<.00001
bridge[['period']+gpm_cols+opm_cols].to_csv(O/'historical_margin_factors_v2.csv',index=False)
cards.append(card(3,'利润率归因：10季历史表格图',['● 最新OPM同比+5.09pp，销量+3.64、汇率+2.29，净售价仅+0.09；销售管理费−1.59。','⊖ 25/09与26/03库存各贡献GPM +4.50／+2.88pp，实际GPM同比均约−0.04pp，其他成本抵消明显。','GPM与OPM分开列示；不将营业利润金额贡献直接当作毛利率贡献。'],gpm_plot+opm_plot,'各列为单季同比桥，日期是季度末；棕色为负贡献、绿色为正贡献，深浅在±6pp封顶，实际值见单元格。*GPM销量行按既有销量利润桥及上年GPM修正收入分母，只是桥换算，不是独立披露的工厂利用率收益。GPM其余影响保留汇率、制造成本、关税及mix等残差，不伪拆。OPM单列关税为0只代表该期桥未单列，非没有关税；退款已在其他成本内。Q2–Q4公司累计桥作差，包含舍入残差。SG&A贡献已入桥，不再叠加费用率变化。',source_summary+' · <a href="../../earnings_review/quarterly_analysis.csv">历史桥及公式数据</a> · <a href="historical_margin_factors_v2.csv">本图数据</a>'))
fig,axes=plt.subplots(1,2,figsize=(10,3.2));x=np.arange(len(ret));labels=ret.fy_end.str[:4];axes[0].bar(x,ret.dividend_total,color=blue,label='所属财年股息');axes[0].bar(x,ret.buyback,bottom=ret.dividend_total,color=green,label='实际回购');axes[0].set_xticks(x,labels);axes[0].set_ylabel('亿日元');axes[0].legend(fontsize=9,frameon=False);axes[1].plot(x,ret.payout_ratio,'o-',color=blue);axes[1].set_xticks(x,labels);axes[1].set_ylim(0,70);axes[1].set_ylabel('总还原率｜占净利润%');
for i,v in enumerate(ret.payout_ratio):axes[1].text(i,v+2,f'{v:.1f}',ha='center',fontsize=9)
fig.tight_layout()
cards.append(card(4,'股东还原：近七年约返还一半利润',['● 已兑现：截至2026年3月财年，股息632亿＋实际回购300亿，总还原率55.7%。','当前股息指引＋本财年已完成回购，对9月11日市值的回报收益率约2.6%。','△ 还原率≠收益率；已完成回购不再是未来待执行买盘。'],svg(fig,'04_returns'),'横轴为财年结束年份。总还原率＝（所属财年股息＋实际回购现金支出）÷净利润。2.6%采用股价68,160日元、股息指引1,000日元及已完成约500亿回购，非资本利得或持续承诺。',source_summary+' · <a href="../../earnings_review/SMC_shareholder_returns_10Y.csv">年度回报表</a>'))
comp='''<table><tr><th>比较维度</th><th>SMC</th><th>Festo</th><th>AirTAC</th></tr><tr><td>通用气动产品覆盖¹</td><td class="high">高：气缸／阀／气源处理</td><td class="high">高：气缸／阀／气源处理</td><td class="high">高：气缸／阀／气源处理</td></tr><tr><td>半导体专用品</td><td>温控、流体控制、真空等；温控FY26/3收入609亿，含非半导体</td><td>晶圆运动、压电流量控制、冷却回路控制；不能视为chiller整机</td><td>通用气动重叠明确；不足以列出可比高端专用品份额</td></tr><tr><td>实际客户／选型证据</td><td>AMAT认可；Intel／Micron温控官方问答</td><td colspan="2">SMC／Festo／AirTAC均见科瑞思／博杰历史采购披露；不代表当前采购比例</td></tr><tr><td>地区收入重心²</td><td>广泛全球布局；中国、日美欧及其他亚洲</td><td>2025欧洲／中东58%，亚洲23%，美洲19%</td><td>2026Q2中国大陆95%，台湾2%，海外3%</td></tr><tr><td>中国气动份额变化³</td><td>自估：中国／香港2023→2024，35%→37%</td><td>未取得独立可比序列，省略</td><td>自估：大陆2023→2024→2025，25–27%→27–29%→29–31%</td></tr></table>'''
cards.append(card(5,'三家公司：核心气动重叠，高端竞争须按产品判断',['● 支持：AirTAC并非与SMC完全错位；Festo具备半导体专用控制能力。','份额自估支持SMC与AirTAC可同时扩张，不能由AirTAC增长推出SMC全面失守。'],comp,'¹高＝目录覆盖完整核心气动类别，不是质量或份额评级。²期间与地理分组不同，仅比较收入重心。³两家公司自估口径不同，不相加、不计算相互转移；未披露份额不填低。','<a href="../official_products_20260914/SMC_竞争研究_v14_PM统一结论_20260914.html">产品、客户与市场份额来源详表</a>'))
evidence='''<div class="evidence"><div><h3>● 支持核心业务韧性</h3><p>2024/11：SMC称中国半导体／医疗价格压力相对温和。</p><p>2025/05：AMAT客户内相关份额约六成自估；产品分母未定义。</p><p>2026/08：跨国客户溢价采用、部分客户回流；未单列半导体。</p></div><div><h3>△ 限制与反证</h3><p>2023：光伏部分气缸确有份额损失，不能写成所有业务都稳固。</p><p>缺少高端同产品／同客户份额序列；不能量化确认“没有显著流失”。</p><p>chiller行业有专业对手；增长不等于夺份额或高利润。</p></div></div><div class="flow"><b>Festo德国拟减员1,300人</b><span>→</span><b>SMC 2026/05称可能带来机会<br><small>当时未计入计划</small></b><span>→</span><b>尚待客户转单兑现<br><small>8月欧洲仍克制提价争份额</small></b></div>'''
s1='https://contents.xj-storage.jp/xcontents/AS00674b/8ead6bdc/d33f/4ce5/af0e/497f2810ff97/20241118115701686s.pdf#page=25';s2='https://contents.xj-storage.jp/xcontents/AS00674b/74f8bcda/5362/4245/924b/7c336663dfd0/20260817134629536s.pdf#page=28'
cards.append(card(6,'投资论点：守住高可靠性客户，争取Festo调整带来的增量',['● 基准判断：高可靠性核心业务有韧性；“高端主战场无显著失份额”获定性支持，尚非量化证实。','● Festo调整提供潜在份额机会；没有足够证据计入已兑现的份额或利润增量。'],evidence,'若核心客户同产品采购比例持续下滑，或竞争者获得具名关键平台量产替代订单，应下修判断。客户留存与定价表述主要来自SMC，非独立份额调查。',f'<a href="{s1}">2024竞争分层</a> · <a href="{s2}">2026客户留存</a> · <a href="https://press.festo.com/en/node/5205">Festo调整公告</a> · <a href="../official_products_20260914/SMC_竞争研究_v14_PM统一结论_20260914.html">完整证据</a>'))
css='''*{box-sizing:border-box}body{margin:0;background:#eef2f6;color:#142537;font:16px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}header{max-width:1120px;margin:auto;padding:32px 34px 16px}h1{font-size:30px;margin:4px 0 10px}header p{color:#536579;margin:6px 0}.wrap{max-width:1120px;margin:auto;padding:0 20px 40px}article{background:white;border:1px solid #dce4ed;border-radius:12px;padding:24px 30px;margin:20px 0;break-after:page}.num{color:#64778b;font-size:12px;letter-spacing:2px}h2{font-size:23px;margin:8px 0 14px}.thesis{border-left:4px solid #2264ac;padding:8px 15px;background:#f3f7fb;font-size:15px;line-height:1.6}.chart{margin:18px 0 8px}.historyplot svg{max-height:none!important}.historyplot{margin:24px 0}.chart svg{display:block;width:100%;height:auto;max-height:355px}p.note,footer{font-size:11px;line-height:1.55;color:#5b6b7d}footer a{color:#2264ac}table{border-collapse:collapse;width:100%;font-size:13px;line-height:1.5}td,th{padding:13px 12px;border:1px solid #dce4ed;text-align:left}th{background:#173b61;color:white}td:first-child{font-weight:600;width:19%}.high{background:#e6f3ed;color:#086b52}.evidence{display:grid;grid-template-columns:1fr 1fr;gap:18px}.evidence>div{padding:15px 20px;background:#edf5f2;border-radius:8px}.evidence>div+div{background:#fff3e9}.evidence h3{font-size:16px;margin:4px 0 12px}.evidence p{font-size:14px;line-height:1.6}.flow{display:flex;gap:15px;align-items:center;justify-content:space-between;padding:22px 10px;text-align:center;color:#245481}.flow b{background:#edf2f8;padding:15px;font-size:14px;border-radius:8px}small{font-size:11px;font-weight:400}@media(max-width:700px){article{padding:18px 14px}.wrap{padding:0 8px}.thesis{font-size:13px}.chart{overflow-x:auto}table{min-width:760px}.evidence{grid-template-columns:1fr}.flow{flex-direction:column}h2{font-size:20px}}@media print{@page{size:A4 landscape;margin:10mm}body{background:white}header{padding:0 15px}header h1{font-size:22px}header p{font-size:11px}.wrap{padding:0;max-width:none}article{border:0;margin:0;padding:12px 20px;min-height:175mm}.chart svg{max-height:105mm}h2{font-size:20px}.thesis{font-size:13px}a{text-decoration:none;color:inherit}article:last-child{break-after:auto}}'''
html='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SMC｜PM六个判断</title><style>'+css+'</style><header><div class="num">INVESTMENT EVIDENCE / 2026.09.14</div><h1>SMC：增长、利润修复与竞争韧性</h1><p>历史图表增强版｜六个判断，每项结论不超过三行；● 支持　⊖ 证伪过强说法　△ 限制／待证</p><p>截至2026年4–6月财报；行情截至9月11日。金额默认亿日元。独立精简版，不替代完整研究。</p></header><main class="wrap">'+''.join(cards)+'</main></html>'
(O/'SMC_PM_六个判断_v2_历史图表_20260914.html').write_text(html)
assert len(cards)==6;assert abs(sum(vals)-295.30)<.01
(O/'delivery_checks_v2.json').write_text(json.dumps({'cards':6,'category_coverage':covered/2709.87,'category_total':covered,'semi_yoy_pct':semigrowth,'semi_increment_share_pct':semicontrib,'op_bridge_sum':sum(vals),'latest_payout_pct':ret.payout_ratio.iloc[-1],'sources':[str(summary),str(R/'earnings_review/近5Q_七行业长表_v2.csv')],'scope':'All charts from existing verified research; no new forecasts; qualitative product coverage not market shares'},ensure_ascii=False,indent=2))
print(O/'SMC_PM_六个判断_v2_历史图表_20260914.html');print('coverage',covered/2709.87,'semi',semi,semigrowth,semicontrib)
