---
type: weekly
period: 2026-10-05/2026-10-09
created: 2026-10-11
author: Wenjun
audience: PM (Lin Tang)
format: "2026-10-06 PM 要求版：第一行结论 → actionable ideas → 仓位状态 → pipeline；新闻一行加链接"
tags: [weekly, industrial, FA, machinery, electronic-components, defense, power]
---

# Industrial Weekly（10/5–10/9）

**本周结论：FA 配对从净空翻成净多——10/13 回补一半 Yaskawa 空头（4.8→2.4mn），多头按 SMC / THK / Daifuku 2 : 1 : 1 配（SMC 维持 2.4mn，新建 THK 1.2mn、Daifuku 1.2mn）。** 主因是空头赔率不够了：Yaskawa 2Q 订单 1,854 亿日元（+38%，新高），公司说 3Q、4Q 维持同一水平，订单给了下一财年利润的想象空间；而股价从 6 月高点已跌 38%，下一财年 P/E 从约 34x 降到约 21.5x，订单同比因基数回落这件事已经提前反映，重估回 22.5–25x 还有 +4%~+16%。但不翻多：上行 +23%（5,900）对下行 −21%（3,800），赔率只有 1 左右，订单里还有下一财年交期的提前下单，要等增产落地、利润率回升（最早 1 月 3Q）。调整后总规模仍 7.2mn，净金额 −2.4→+2.4mn，净 beta −5.7→+2.5mn。

## 1. Actionable ideas

| # | 标的 | 建议 | 一句话理由 | 什么情况下改变 |
|---|---|---|---|---|
| 1 | **Yaskawa（6506）** | **S 4.8mn → 回补一半到 2.4mn**（回补比例可调；10/13 高开 ≤5% 开盘执行，否则收盘执行） | 估值已先杀完：下一财年 P/E 约 21.5x（一致预期 EPS 222），Base 222×22.5x = 4,995（+4%）、Upside 236×25x = 5,900（+23%），空头赔率不够。剩下 2.4mn 不翻多：Downside 是明年利润落空约 14%（提前下单回吐、稀土只保证到下半年）190×20x = 3,800（−21%），赔率约 1。剩余仓位同时是多头组合的对冲腿：近一年对 TOPIX beta 1.95，高于 SMC 1.52、THK 1.60、Daifuku 1.38 | 3Q 订单环比明显低于 2Q 的 1,854 亿 → 重新加回空头；增产落地、利润率回升（1 月 3Q 验证）→ 平掉剩余 2.4mn |
| 2 | **SMC（6273）** | **L 2.4mn 维持**，多头组合的主腿（2 : 1 : 1 里的 2）；AirTAC 无反证后可加，上限 10mn | 论点是库存充足、迎接上行周期；本周 Yaskawa 订单 +38%、Rorze 半导体订单环比 +87%、机床订单 +60%，都说明周期还在往上走，SMC 有货可交，最先吃到需求；BofA Hotta 也把它列为下一财年首选 | AirTAC 用低价抢走 SMC 半导体份额得到证实（10/12 见厂长时验证）；或 11 月 2Q 订单环比下滑；或库存没能兑现成利润（2Q 收入和利润率没跟上订单） |
| 3 | **THK（6481）** | **新 L 1.2mn**（与 Yaskawa 同步执行） | BofA Hotta 下一财年首选之一：他估明年 OP 约 700 亿，BBG 一致预期在 600 亿出头，上修空间大；本周 +3.0% 到 6,710。目前只有 Hotta 一家的数，我们自己还没建模 | FA 订单增速回落，或 11 月 3Q 财报证伪明年 700 亿的路径 |
| 4 | **Daifuku（6383）** | **新 L 1.2mn**（与 Yaskawa 同步执行） | 市场按「利润见顶」给 20.5x，但 Rorze 订单连续三季创新高，说明晶圆厂搬运订单没见顶；回到扩张期中位 23x → 6,330 日元（+10%）；本周 −1.3% 到 5,773 | 看 11/11 3Q 洁净室订单：≥900 亿加，<800 亿减 |
| 5 | **ROHM（6963）** | L 5mn，等 ¥4,700 附近建（未触发） | 本周 −5.6% 到 4,934，离建仓价还差约 5%；BofA Kubota 认为短期 ROHM 比 Murata 有看点，催化剂是收购东芝半导体 | Mitsubishi Electric 拿到功率半导体整合的过半主导权 → 不建 |

## 2. FA 的看法

本周看了 Yaskawa、Rorze、OSG 的业绩和 9 月机床订单，结论如下：

1. **需求没问题，关键是 YoY 降多快。** 9 月机床订单 ¥223.2bn，创历史新高，YoY +60.4%。CLSA 预测 10 月回落到 +43.5% 左右，主要是 9 月工作日多；2027 年全年 +20%。接下来要看的是，实际降速跟这条预测路径比是快还是慢。
2. **但 FA 在资本开支链的最末端，顶部不远。** BofA 预计云厂商资本开支增速从 2026 年的 +98% 降到 2027 年的 +37%，半导体资本开支增速 2028 年降到 +10% 左右。FA 是上游投资的最后一环，股价会提前反应上游的放缓，所以这一轮更适合做波段，不适合长期持有。
3. **现在的瓶颈是交付。** 订单都很强，差别在谁能交得出货。气动、传感器这类轻型 FA 用的零部件少，有库存缓冲，最占优势。
4. **排序：SMC > Keyence > THK > OSG > Daifuku > Yaskawa > Fanuc > Rorze**
   - SMC：交付有缓冲，估值合理，首选。
   - Keyence：交付最稳，见顶阶段最抗跌，但估值贵。
   - THK：估值便宜，但跟资本开支周期挂钩最紧，只当交易品种。
   - Yaskawa：说明会上表示 FY2/28 的需求有一部分提前到了本财年，稀土只能保到下半年，两头都有风险。
   - Rorze：管理层已经预告下半年订单回落。

## 3. Pipeline（按优先级）

1. **10/12–13 AirTAC 厂长调研 + Yaskawa 说明会**：验证 AirTAC 在半导体领域的报价和份额，这是 SMC 多头唯一的反证；问 Yaskawa 订单里要求下一财年交货的提前下单占比（下一次做空 FA 的种子）。
2. **10/15（周四）Namura Shipbuilding（7014）teach-in**：8 月 thesis 结论是「不追高，3,500–3,800 接」，现价 4,635（10/9），和当时 4,605 基本没变；会前用 9/8 面谈（再生基金认定、10 年投 1,500 亿、建造能力翻倍）、Oshima 180 亿和 MHI 下关扩产更新一遍：同业都在扩产能，要回答周期顶部的利润率还能撑多久。
3. **Daifuku 讲给 PM**：时间未定，下周在 FA 调研途中可能要电话接入讲；邮件和一页纸已经备好。

## 4. 本周会议（5 场）

- **Kawasaki Heavy 2030 进度报告会（10/6）**：上修的是规模不是利润率，防卫 2030 年 7,000–8,000 亿但出口因产能不算 → 对空头偏支持。[[Meetings/Corporate/7012 川崎重工 グループビジョン2030進捗報告会 整理稿 2026-10-06|纪要]]
- **PowerX 投资者电话（CLSA，10/6）**：今年 400 亿全部在手、明年 700 亿已订 72%；公司明说日本 AI 数据中心需求现在很小，大项目要到 2028–29 年。[[Meetings/Corporate/485A パワーエックス 投資家コール 整理稿 2026-10-06|纪要]]
- **BofA Hotta 机械（10/8）**：财报前看多 Yaskawa（事后看他对了），FA「减速但高位持续」；下一财年首选 SMC、THK，Keyence 36–37 倍太贵，CKD 偏弱。[[Meetings/Sell-side/BofA Hotta on 機械 (安川決算前・FA・防衛・建機) 整理稿 2026-10-08|纪要]]
- **BofA Kubota 电子零部件（10/8）**：短期 ROHM 好于 Murata（东芝半导体收购预计 7,000–8,000 亿落地）；他看空的票都在回购，暂时碰不了；TDK 看下一期中期计划。[[Meetings/Sell-side/電子部品 (ローム・村田・TDK・京セラ・ミネベア) 1x1 整理稿 2026-10-08|纪要]]
- **SMBC Nikko 山口 三井金属（10/9）**：股价从高点跌 59%，主因是亚洲买方出清 BSP 题材；MicroThin 今年产能计划从 10 万上修到 60 万，明年可能满产，新社长愿意涨价。[[Meetings/Sell-side/5706 三井金属 SMBC日興 (MicroThin・BSP・非鉄) 整理稿 2026-10-09|纪要]]

## 5. 评级变动（与 book 相关）

| 日期 | 标的 | 券商 | 变动 | 怎么读 |
|---|---|---|---|---|
| 10/5–10/9 | Yaskawa | SBI / Macquarie / Mizuho | SBI 目标价 7,000→6,250；Macquarie 6,000→6,200；Mizuho 恢复覆盖给买入、目标价 5,800 | 财报后各家维持买入，没有下调 |
| 10/7 | SMC / CKD | Mizuho | 均为中立，SMC 目标价 69,000、CKD 6,050 | Mizuho 机械板块整体重新覆盖（同批 Hitachi Construction Machinery 买入） |
| 10/5 | Daifuku | Nomura | Buy 维持，目标价 8,000→6,900 | 下修后距现价仍 +20% |
| 10/7 | Sumitomo Rubber | Tokai Tokyo | 看多维持，目标价 2,870→2,460 | 看多的券商也在下修 |

## 6. 本周数据与新闻

- **机床 9 月订单速报** 2,232 亿日元，同比 +60%，单月历史最高；在手订单超过 1 兆日元。[日经](https://www.nikkei.com/article/DGXZQOUC05AR90V01C26A0000000/)
- **FA 同业财报全面上修**：Rorze 全年 OP 指引 381→531 亿，OSG 300→360 亿，Nachi-Fujikoshi 维持 153 亿（进度 75%）。
- **Hiwin 9 月营收**同比 +30%（8 月 +42%，单月回落主要是基数；3 个月滚动 +35% 持平，环比 +0.5% 低于季节性；AirTAC、Delta 尚未公布）。[来源](https://winvest.tw/News/Detail/95260)
- Yaskawa、Kawasaki Heavy、Fanuc 联手推国产 AI 模型。[日经Business](https://x.com/nikkeibusiness/status/2107493628751003770)
- Oasis 要求 Nidec 考虑私有化。[日经](https://x.com/nikkei/status/2107795602624905261)
- Komatsu 创上市以来新高，GS 给买入。[日经](https://x.com/nikkei/status/2106969289408352306)
- Oshima Shipbuilding 香焼工厂投资约 180 亿日元，用国家补助扩产；继 Namura 之后又一家船厂扩产能，Namura teach-in 用。[日经](https://www.nikkei.com/article/DGXZQOJC057M20V01C26A0000000/)
- Kawasaki Heavy 宣布「向机器人企业转型、全事业导入物理 AI」；只看到标题，方向和 10/6 报告会一致（报告会上利润率目标没变）。[日经](https://www.nikkei.com/article/DGXZQOUC040EZ0U6A001C2000000/)
- Disco 4–9 月单体营收「符合预期」，股价当天 −6%。[日经](https://x.com/nikkei/status/2107736210613428286)
- 自民党防卫产业议员联盟提案 5,000 亿日元促进新创企业进入防卫产业。[日经](https://www.nikkei.com/article/DGXZQOUA0777R0X01C26A0000000/)

本周 TOPIX +0.3%，机械 −0.8%，电气设备 +1.3%，精密 +3.3%。

## 7. 下周日程（10/12–10/16）

| 日期 | 事件 | 看什么 |
|---|---|---|
| 10/12（日本休市） | Macquarie 中国 FA 调研团 Day 1，见 AirTAC 厂长 | AirTAC 在半导体领域的报价与份额（SMC 多头的反证） |
| 10/13 | Yaskawa 财报次日 + 说明会；Takeuchi 2Q | 高开 ≤5% 开盘回补一半 Yaskawa、新建 THK 1.2mn / Daifuku 1.2mn，否则收盘执行；说明会看伺服开工率百分比、下一财年交期订单占比 |
| 10/15（周四） | **Namura Shipbuilding（7014）teach-in**；BofA 主办 Yaskawa IR call；内阁府 8 月机械订单；METI 8 月生产确报；TSMC 3Q | 半导体资本开支对 Daifuku、Rorze 的延续性 |
| 10 月中 | AirTAC / Delta 9 月营收；JSEA 9 月出口船订单 | — |
| 之后 | Fanuc 10/23 · Keyence 10/29 · Daifuku 11/11 | — |

---
细节：[[Research/Stock Ideas/Yaskawa 6506 — FY26Q2 Earnings Preview (2026-10)|Yaskawa 财报前瞻与财报后结论]] · [[Research/Sector Reviews/FA 工厂自动化 一页纸 2026-10-07|FA 一页纸]] · [[Research/Stock Ideas/Daifuku 6383 — Long thesis (2026-10)|Daifuku thesis]] · 上一期 [[Research/Weekly/2026-10-02 Industrial Weekly]]
