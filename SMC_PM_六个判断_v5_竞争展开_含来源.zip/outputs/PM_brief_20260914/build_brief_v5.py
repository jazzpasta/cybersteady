from pathlib import Path
import pandas as pd, numpy as np, io, json, hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
R=Path('/Users/wenjun/Downloads/Nemesis/Almighty/research/smc_relval'); O=R/'outputs/PM_brief_20260914';O.mkdir(exist_ok=True)
font=FontProperties(fname='/System/Library/Fonts/Supplemental/Arial Unicode.ttf');plt.rcParams.update({'font.family':font.get_name(),'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'path','axes.unicode_minus':False})
blue='#2264ac'; green='#168477'; red='#b74641';gray='#718096'
def svg(fig,name):
 b=io.StringIO();fig.savefig(b,format='svg',bbox_inches='tight',facecolor='white');fig.savefig(O/(name+'.png'),dpi=150,bbox_inches='tight');plt.close(fig);return b.getvalue()[b.getvalue().index('<svg'):]
def card(n,title,lines,chart,note,source):
 return f'<article><div class="num">{n:02d} / 06</div><h2>{title}</h2><div class="thesis">'+''.join('<div>'+x+'</div>' for x in lines)+f'</div><div class="chart">{chart}</div><p class="note">{note}</p><footer>{source}</footer></article>'

def table_plot(values, rows, cols, title, name, signed=True, neutral_rows=()):
 from matplotlib.colors import TwoSlopeNorm
 arr=np.asarray(values,dtype=float)
 fig,ax=plt.subplots(figsize=(13,max(2.8,.39*len(rows)+1.15)))
 colors=np.zeros((*arr.shape,4));cmap=plt.get_cmap('BrBG'); norm=TwoSlopeNorm(vmin=-6,vcenter=0,vmax=6)
 for i in range(len(rows)):
  for j in range(len(cols)):
   colors[i,j]=(.94,.96,.98,1) if i in neutral_rows or not signed else cmap(norm(np.clip(arr[i,j],-6,6)))
 ax.imshow(colors,aspect='auto');ax.set_xticks(range(len(cols)),cols,fontsize=10);ax.xaxis.tick_top();ax.tick_params(length=0,pad=8);ax.set_yticks(range(len(rows)),rows,fontsize=10)
 for i in range(len(rows)):
  for j in range(len(cols)):
   v=0.0 if abs(arr[i,j])<0.005 else arr[i,j];txt=(f'{v:+.2f}' if signed and i not in neutral_rows else f'{v:.2f}' if signed else f'{v:,.0f}')
   if name=='03_opm_history_v4' and rows[i]=='关税（单列项）' and cols[j]=='26/06':txt='并入成本*'
   ax.text(j,i,txt,ha='center',va='center',fontsize=10,color='white' if signed and i not in neutral_rows and abs(v)>3.5 else '#142537')
 ax.set_xticks(np.arange(-.5,len(cols),1),minor=True);ax.set_yticks(np.arange(-.5,len(rows),1),minor=True);ax.grid(which='minor',color='white',lw=2);ax.tick_params(which='minor',length=0)
 for spine in ax.spines.values():spine.set_visible(False)
 ax.set_title(title,pad=35,loc='left',fontsize=12,fontweight='bold');fig.tight_layout()
 return '<div class="historyplot">'+svg(fig,name)+'</div>'

summary=R/'SMC_Research_Summary_20260914.md'
source_summary='<a href="../../SMC_Research_Summary_20260914.md">已核研究汇总（2026-09-14）</a>'
q=pd.read_csv(R/'earnings_review/quarterly_financials.csv').tail(10); bridge=pd.read_csv(R/'earnings_review/quarterly_analysis.csv');ret=pd.read_csv(R/'earnings_review/SMC_shareholder_returns_10Y.csv').tail(7)
d=pd.read_csv(R/'earnings_review/近5Q_七行业长表_v2.csv');a=d.groupby(['季度末','行业'])['行业收入估算_亿日元'].sum().unstack();start=a.loc['2025-06-30'];end=a.loc['2026-06-30'];order=end.sort_values().index;yoy=(end/start-1)*100
ordered=['半导体','电机','汽车','机械','食品','医疗','其他']; dates=[pd.Timestamp(z).strftime('%Y/%m') for z in a.index]
fig,axes=plt.subplots(1,2,figsize=(12,3.5),gridspec_kw={'width_ratios':[1.4,1]});colors=['#2264ac','#7e61a2','#168477','#d78832','#cc6262','#688fa6','#a3adba']
for k,c in zip(ordered,colors):axes[0].plot(range(5),a[k],marker='o',lw=2,label=k,color=c)
axes[0].set_xticks(range(5),dates,rotation=20);axes[0].set_ylabel('收入估算｜亿日元');axes[0].set_ylim(bottom=0);axes[0].legend(ncol=4,fontsize=9,loc='upper left');axes[0].grid(axis='y',alpha=.15)
axes[1].barh(ordered[::-1],yoy[ordered[::-1]],color=colors[::-1]);axes[1].set_xlabel('最新季同比增长｜%');axes[1].set_xlim(0,100)
for i,v in enumerate(yoy[ordered[::-1]]):axes[1].text(v+1,i,f'{v:.1f}%',va='center',fontsize=10)
fig.tight_layout();growth_chart=svg(fig,'01_downstream_trend_v2')
growth_table=table_plot(a[ordered].T.values,ordered,dates,'各下游连续5季收入估算｜亿日元','01_downstream_history_v2',signed=False)
qoq=a[ordered].pct_change().iloc[1:]*100
growth_qoq=table_plot(qoq.T.values,ordered,dates[1:],'环比成长｜%（颜色仅表示正负，非份额变化）','01_downstream_qoq_v2')
covered=end.sum();prior=start.sum(); semigrowth=yoy['半导体'];semi=end['半导体']; semicontrib=(end['半导体']-start['半导体'])/(covered-prior)*100

regions=['日本','北美','欧洲','中华圈','其他亚洲']
region_totals=d.groupby(['季度末','地区'])['行业收入估算_亿日元'].sum().unstack()[regions]
region_growth=(region_totals.iloc[-1]/region_totals.iloc[0]-1)*100
fig,axes=plt.subplots(2,3,figsize=(13,7))
region_tables=[]; region_exports=[]
for ax,region in zip(axes.flat,regions):
 rd=d[d['地区']==region].pivot(index='季度末',columns='行业',values='行业收入估算_亿日元')[ordered]
 bottom=np.zeros(len(rd))
 for k,c in zip(ordered,colors):
  ax.bar(range(5),rd[k],bottom=bottom,color=c,label=k,width=.65);bottom+=rd[k].values
 ax.set_xticks(range(5),[z[2:] for z in dates],rotation=30);ax.set_ylim(bottom=0);ax.set_ylabel('亿日元');ax.set_title(f'{region}｜最新同比 {region_growth[region]:+.1f}%');ax.grid(axis='y',alpha=.12)
 latest=rd.iloc[-1]; prev=rd.iloc[-2]; first=rd.iloc[0]
 rows=''
 for industry in ordered+['地区合计']:
  v=rd.sum(axis=1) if industry=='地区合计' else rd[industry]
  yoy_r=(v.iloc[-1]/v.iloc[0]-1)*100;qoq_r=(v.iloc[-1]/v.iloc[-2]-1)*100;share=v.iloc[-1]/latest.sum()*100
  cells=''.join(f'<td>{n:,.1f}</td>' for n in v)
  for n in [yoy_r,qoq_r]:cells+=f'<td style="color:{green if n>=0 else red};font-weight:600">{n:+.1f}%</td>'
  cells+=f'<td>{share:.1f}%</td>'
  rows+=f'<tr><th>{industry}</th>{cells}</tr>'
  region_exports.append({'地区':region,'应用':industry,**dict(zip(dates,v.values)),'最新YoY_pct':yoy_r,'最新QoQ_pct':qoq_r,'当地应用占比_pct':share})
 header='<th>当地应用</th>'+''.join(f'<th>{z}</th>' for z in dates)+'<th>最新YoY</th><th>最新QoQ</th><th>当地占比</th>'
 region_tables.append(f'<details open class="region-detail"><summary>{region} → 下游应用｜最新收入 {latest.sum():,.1f} 亿日元</summary><div style="overflow-x:auto"><table class="regional"><thead><tr>{header}</tr></thead><tbody>{rows}</tbody></table></div></details>')
axes.flat[-1].axis('off');handles,labels_reg=axes.flat[0].get_legend_handles_labels();axes.flat[-1].legend(handles,labels_reg,loc='center',ncol=2,frameon=False,title='各地区应用构成')
fig.suptitle('国家／地区 → 下游应用：连续5季收入构成（各图纵轴独立）',fontsize=15);fig.tight_layout()
regional_chart=svg(fig,'01_regions_applications_v4')
regional_html='<h3>地区下的应用：规模与成长</h3>'+regional_chart+''.join(region_tables)
pd.DataFrame(region_exports).to_csv(O/'regional_applications_5Q_v4.csv',index=False,encoding='utf-8-sig')
assert len(region_exports)==40
assert np.allclose(region_totals.sum(axis=1),a.sum(axis=1))

cards=[]
cards.append(card(1,'下游：地区 × 应用，连续5季规模与成长',[f'● 半导体由{start["半导体"]:,.0f}亿增至{semi:,.0f}亿，最新季同比{semigrowth:.0f}%，贡献已覆盖地区增收约{semicontrib:.0f}%。','按日本、北美、欧洲、中华圈、其他亚洲分别展开七类应用，列示5季规模及最新同比／环比。'],regional_html+'<details><summary>补充：五地区应用合计</summary>'+growth_chart+growth_table+growth_qoq+'</details>',f'2025年4–6月至2026年4–6月，横轴为季度末。地区按经营公司所在地归类，非终端客户所在国；中华圈不等于中国大陆，北美／欧洲／其他亚洲未进一步拆国家。表中规模是SMC当地分应用收入估算，不是下游行业总市场。五个主要经营地区，最新覆盖集团收入{covered/2709.87:.1%}；各季地区收入×当地行业占比估算，取整占比会影响增速。更早同口径七行业数据不足，故只有最新季可算同比；首季环比不填零。环比表颜色深浅在±6%封顶，实际值见单元格。电机＝电气／电子。',source_summary+' · <a href="../../earnings_review/近5Q_七行业长表_v2.csv">5季行业原表</a> · <a href="regional_applications_5Q_v4.csv">地区×应用图表数据</a>'))
fig,axes=plt.subplots(1,2,figsize=(10,3.1));x=np.arange(len(q));labels=pd.to_datetime(q.CurPerEn).dt.strftime('%y/%m')
for ax,col,title,c in [(axes[0],'gpm','毛利率 GPM',blue),(axes[1],'opm','营业利润率 OPM',green)]:
 ax.plot(x,q[col],'-o',color=c,lw=2);ax.set_xticks(x,labels,rotation=45);ax.set_title(title);ax.set_ylabel('%');ax.grid(axis='y',alpha=.15);ax.text(x[-1],q[col].iloc[-1]+.4,f'{q[col].iloc[-1]:.2f}%',ha='right',color=c,fontweight='bold')
fig.tight_layout()
cards.append(card(2,'利润率：恢复已发生，尚未回到历史高位',['● 支持修复：2026年4–6月GPM 46.84%、OPM 27.30%，同比各升2.55／5.09个百分点。','△ 限制：这是报告利润率，含库存评价及关税退款影响；不能直接当持续性核心利润率。'],svg(fig,'02_margins'),'两图纵轴独立、均非零起点；单季财报实际。2023年3月止全年GPM／OPM为51.06%／31.31%，仅作历史参照。',source_summary+' · <a href="../../earnings_review/quarterly_financials.csv">季度财务</a>'))
b=bridge.iloc[-1];labs=['销量','净售价','汇率','库存评价','制造等','销售管理费','舍入差'];vals=[b.volume,b.price,b.fx,b.inventory,b.manufacturing_other,b.sga,b.op_residual]
periods=pd.to_datetime(bridge.period).dt.strftime('%y/%m').tolist()
# Bridge-based estimates: FX adjusts both profit numerator and sales denominator.
bridge['fx_gpm_pp']=(bridge.fx-(bridge.gpm-bridge.gpm_yoy)/100*bridge.sales_fx)/bridge.sales*100
bridge['manufacturing_other_gpm_pp']=bridge.manufacturing_other/bridge.sales*100
bridge['gpm_remaining_pp']=bridge.gpm_yoy-bridge[['volume_gpm_pp','price_gpm_pp','fx_gpm_pp','inventory_gpm_pp','manufacturing_other_gpm_pp']].sum(axis=1)
gpm_cols=['gpm','gpm_yoy','volume_gpm_pp','price_gpm_pp','fx_gpm_pp','inventory_gpm_pp','manufacturing_other_gpm_pp','gpm_remaining_pp']
gpm_rows=['报告GPM（%）','GPM同比变化','销量桥换算*','净售价','汇率变动*','库存评价','加工费／材料费／其他*','未分拆影响（残差）']
gpm_plot=table_plot(bridge[gpm_cols].T.values,gpm_rows,periods,'GPM历史归因｜2024年1–3月至2026年4–6月；贡献单位：百分点','03_gpm_history_v3',neutral_rows=(0,))
opm_cols=['opm','opm_yoy','volume_opm_pp','price_opm_pp','fx_opm_pp','inventory_opm_pp','manufacturing_other_opm_pp','sga_opm_pp','tariff_opm_pp','scope_opm_pp','opm_residual_pp']
opm_rows=['报告OPM（%）','OPM同比变化','销量','净售价','汇率','库存评价','加工费／材料费／其他','销售管理费','关税（单列项）','并表范围','桥接残差']
opm_plot=table_plot(bridge[opm_cols].T.values,opm_rows,periods,'OPM历史归因｜贡献单位：百分点；各贡献相加＝OPM同比变化','03_opm_history_v4',neutral_rows=(0,))
assert np.max(np.abs(bridge[gpm_cols[2:]].sum(axis=1)-bridge.gpm_yoy))<.00001
assert np.max(np.abs(bridge[opm_cols[2:]].sum(axis=1)-bridge.opm_yoy))<.00001
bridge['tariff_display_note']=np.where(bridge.period=='2026-06-30','关税退款已并入加工费／材料费／其他；tariff_opm_pp=0仅为单列桥记账值，不代表经济影响为0','公司桥单列金额；0不等同于没有关税影响')
bridge[['period']+gpm_cols+opm_cols+['tariff_display_note']].to_csv(O/'historical_margin_factors_v4.csv',index=False)
cards.append(card(3,'利润率归因：10季历史表格图',['● 最新OPM同比+5.09pp，销量+3.64、汇率+2.29，净售价仅+0.09；销售管理费−1.59。','⊖ 25/09与26/03库存各贡献GPM +4.50／+2.88pp，实际GPM同比均约−0.04pp，其他成本抵消明显。','GPM与OPM分开列示；不将营业利润金额贡献直接当作毛利率贡献。'],gpm_plot+opm_plot,'各列为单季同比桥，日期是季度末；棕色为负贡献、绿色为正贡献，深浅在±6pp封顶，实际值见单元格。*GPM销量行按既有销量利润桥及上年GPM修正收入分母，只是桥换算，不是独立披露的工厂利用率收益。GPM汇率贡献＝（公司利润桥汇率金额−上年GPM×收入桥汇率金额）÷本季收入；加工费／材料费／其他＝公司利润桥该合并项÷本季收入。两项均为营业利润桥映射至毛利率的估算，假设对应利润影响归属于毛利，不能排除公司汇率桥含费用端影响；不是公司独立披露的完整GPM桥。原文项目：為替変動、加工費・材料費・他。材料不单独拆分。剩余残差＝实际GPM同比变化−表内五项贡献，包含未单列关税、并表、其他未解释影响及映射误差，不等同于纯成本或产品组合影响。*26/06关税栏“并入成本”依据2026-08-07公司说明会第3页：关税退款的一部分冲减加工费／材料费／其他。该合并项净影响−8亿（−0.30pp）已含退款收益，不应再次加总。公开问答披露收到退款35亿，收款不等于全部计入当季损益，故不把35亿直接作为桥贡献。其余期单列关税为0仅表示未单列，非没有关税影响。Q2–Q4公司累计桥作差，包含舍入残差。SG&A贡献已入桥，不再叠加费用率变化。',source_summary+' · <a href="../../earnings_review/quarterly_analysis.csv">历史桥及公式数据</a> · <a href="historical_margin_factors_v4.csv">本图数据</a> · <a href="../../earnings_review/20260807.txt">公司说明会第3页（关税计入成本说明）</a>'))
fig,axes=plt.subplots(1,2,figsize=(10,3.2));x=np.arange(len(ret));labels=ret.fy_end.str[:4];axes[0].bar(x,ret.dividend_total,color=blue,label='所属财年股息');axes[0].bar(x,ret.buyback,bottom=ret.dividend_total,color=green,label='实际回购');axes[0].set_xticks(x,labels);axes[0].set_ylabel('亿日元');axes[0].legend(fontsize=9,frameon=False);axes[1].plot(x,ret.payout_ratio,'o-',color=blue);axes[1].set_xticks(x,labels);axes[1].set_ylim(0,70);axes[1].set_ylabel('总还原率｜占净利润%');
for i,v in enumerate(ret.payout_ratio):axes[1].text(i,v+2,f'{v:.1f}',ha='center',fontsize=9)
fig.tight_layout()
cards.append(card(4,'股东还原：近七年约返还一半利润',['● 已兑现：截至2026年3月财年，股息632亿＋实际回购300亿，总还原率55.7%。','当前股息指引＋本财年已完成回购，对9月11日市值的回报收益率约2.6%。','△ 还原率≠收益率；已完成回购不再是未来待执行买盘。'],svg(fig,'04_returns'),'横轴为财年结束年份。总还原率＝（所属财年股息＋实际回购现金支出）÷净利润。2.6%采用股价68,160日元、股息指引1,000日元及已完成约500亿回购，非资本利得或持续承诺。',source_summary+' · <a href="../../earnings_review/SMC_shareholder_returns_10Y.csv">年度回报表</a>'))
comp='''<table><tr><th>比较维度</th><th>SMC</th><th>Festo</th><th>AirTAC</th></tr><tr><td>通用气动产品覆盖¹</td><td class="high">高：气缸／阀／气源处理</td><td class="high">高：气缸／阀／气源处理</td><td class="high">高：气缸／阀／气源处理</td></tr><tr><td>半导体专用品</td><td>温控、流体控制、真空等；温控FY26/3收入609亿，含非半导体</td><td>晶圆运动、压电流量控制、冷却回路控制；不能视为chiller整机</td><td>通用气动重叠明确；不足以列出可比高端专用品份额</td></tr><tr><td>实际客户／选型证据</td><td>AMAT认可；Intel／Micron温控官方问答</td><td colspan="2">SMC／Festo／AirTAC均见科瑞思／博杰历史采购披露；不代表当前采购比例</td></tr><tr><td>地区收入重心²</td><td>广泛全球布局；中国、日美欧及其他亚洲</td><td>2025欧洲／中东58%，亚洲23%，美洲19%</td><td>2026Q2中国大陆95%，台湾2%，海外3%</td></tr><tr><td>中国气动份额变化³</td><td>自估：中国／香港2023→2024，35%→37%</td><td>未取得独立可比序列，省略</td><td>自估：大陆2023→2024→2025，25–27%→27–29%→29–31%</td></tr></table>'''

from bs4 import BeautifulSoup
full=BeautifulSoup((R/'outputs/official_products_20260914/SMC_竞争研究_v14_PM统一结论_20260914.html').read_text(),'html.parser')
full_url='../official_products_20260914/SMC_竞争研究_v14_PM统一结论_20260914.html'
def evidence_link(anchor,label='原始证据及口径'):
 return f'<a href="{full_url}#{anchor}">{label}</a>'
def ct(headers,rows):
 return '<div style="overflow-x:auto"><table class="competition"><thead><tr>'+''.join(f'<th>{h}</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join(f'<td>{v}</td>' for v in row)+'</tr>' for row in rows)+'</tbody></table></div>'
product_rows=[
['气缸／执行元件','覆盖高；收入权重30.2%¹','覆盖高；气动＋电动定位','覆盖高；2025收入47.39%','直接重叠高；不能把通用件排除出SMC主战场'],
['阀／控制元件','覆盖高；阀23.6%¹','覆盖高；阀岛、比例／压电控制','覆盖高；2025控制元件20.88%','三者均有核心产品，仍需按型号和介质比较'],
['气源处理／接头／传感','FRL、接头、测量控制广泛','FRL、连接和压力／流量控制','气源处理2025收入5.66%；接头及传感','应用于汽车、电子、机械等共同客户'],
['电动运动／线性传动','LEFS等电动轴','晶圆运动、定位及自动化系统','LSH等线性导轨','导轨组件不等于完整伺服／电动轴；不按名称硬比'],
['半导体温控整机','HRZ／HRZC；已核Intel、Micron销售','冷却回路控制有覆盖，不能等同chiller整机','未取得可比前道chiller整机及具名量产证据','三家比较不足：还需ATS、GST、UNISEM等专业温控厂'],
['半导体真空／高纯流体','XLA／XGTP、AP Tech、LVC／LQ等','MH2先导控制、VEFC流量、VTEP比例控制','SM-ARH洁净减压阀；专用品边界持续扩展','功能分工多；“服务半导体”不代表同工艺直接替换']]
product_html='<h3>5A｜哪些产品真正重叠？</h3>'+ct(['产品线','SMC','Festo','AirTAC','竞争含义'],product_rows)+'<p class="note">高指已核目录覆盖，不是质量／市场份额评级。¹SMC综合报告2025构成图，图自身未独立标注统计期；AirTAC为2025自然年，分类不同。SMC执行元件＋阀合计53.8%，不等于全部面临AirTAC替代。'+evidence_link('smc-product-weight')+' · '+evidence_link('festo-parker-update','Festo专用品证据')+'</p>'
gallery=[]
for alt,caption in [('SMC CQ2 薄型气缸','通用执行：SMC CQ2'),('SMC SY 电磁阀','阀控制：SMC SY'),('SMC HRZC 温控整机','半导体温控：SMC HRZC'),('SMC XLA 系列真空阀','真空控制：SMC XLA'),('Festo VEFC 质量流量控制器','流量控制：Festo VEFC'),('AirTAC LSH Series Standard Linear Guide','线性导向：AirTAC LSH')]:
 im=full.find('img',alt=alt);assert im is not None,alt
 gallery.append(f'<figure><img src="{im["src"]}" alt="{alt}"/><figcaption>{caption}</figcaption></figure>')
product_html+='<div class="product-gallery">'+''.join(gallery)+'</div><p class="note">官网产品示例图，说明产品形态；不是三家公司同规格对照。'+evidence_link('pictures','40类产品与官网链接')+'</p>'
customer_rows=[
['AMAT｜设备OEM','客户方2024／2025供应商奖确认关系；SMC 2025自估客户内相关份额约60%','未取得同等强度的具名当前采购证据','60%未给清晰产品／金额分母，只有单期，不能当chiller或全部采购份额'],
['Intel／Micron｜晶圆厂','2024-08官方问答明确chiller销售，经指定商社','未取得三家在同客户同型号的采购对照','已核终端客户；内部可归“其他”，应用表会漏计部分半导体终端需求'],
['Lam｜设备OEM','历史单台配置列SMC HRZ004-L-C','不能据现有记录确认Festo／AirTAC当前同平台供货','历史设备证据；不等于当前全线认证、直供合同或采购份额'],
['科瑞思／博杰｜设备厂','历史采购出现SMC','同客户历史采购亦出现Festo／AirTAC','存在真实客户重叠；不能由公司名单推出同部件互相替代'],
['PVA TePla｜半导体设备厂','本例未确认SMC同机型供货','Festo接头进入GIGA 690／AutoFab官方规格','压缩空气接口选型，不是整套高纯工艺气路或chiller订单']]
customer_html='<h3>5B｜客户重叠：供货、选型与历史装机分开看</h3>'+ct(['客户层级','SMC证据','Festo／AirTAC及对照','能说明什么／边界'],customer_rows)+'<p class="note">未取得证据不代表没有客户。'+evidence_link('customers')+' · '+evidence_link('chiller','Intel／Micron官方证据')+' · '+evidence_link('festo-parker-update','共同客户及Festo设备选型')+'</p>'
region_rows=[
['中国／中华圈','中国通用件价格压力真实；2025年3月止财年中国制造＋销售整体利润增长（公司定性）','中国收入金额／占集团比例：现有已核资料未取得单独数值。中国气动市场份额约13%为AirTAC材料估计（图表统计期未标），不是Festo中国收入占比。2026-08 SMC称欧洲对手在中国走弱，不能据此量化Festo损失','2026Q2大陆收入95%、台湾2%、其他海外3%','通用气动重叠高；SMC＋AirTAC可能同时增份额'],
['欧洲','2026-08仍克制提价、争取份额；供给能力也是约束','2025收入地区：欧洲／中东58%，亚洲23%，美洲19%；德国重组拟减约1300岗','集团收入高度集中大陆，不能由此断言欧洲没有项目','SMC／Festo直接竞争重要；裁员尚非已兑现转单'],
['北美及跨国半导体链','美国OEM设计／采购与亚洲晶圆厂终端需求相连','SMC管理层称美国除特殊领域外主要对手也是Festo','头部半导体OEM具名量产证据不足','国家开票收入、OEM设计地、终端装机地必须分开']]
region_html='<h3>5C｜地区重叠：在哪里争同一批客户？</h3>'+ct(['市场','SMC','Festo','AirTAC','判断'],region_rows)+'<p class="note">不同公司／年份的地区分类不同，仅比较经营重心，不据此计算份额。'+evidence_link('regions')+' · '+evidence_link('airtac-latest-scope','AirTAC地区口径')+'</p>'
fig,axs=plt.subplots(1,3,figsize=(13,3.5))
axs[0].plot([2023,2024],[35,36],'o-',label='全球',color=blue);axs[0].plot([2023,2024],[35,37],'o-',label='中国及香港',color=green);axs[0].set_title('SMC：公司自估气动份额');axs[0].set_xticks([2023,2024]);axs[0].set_ylim(0,45);axs[0].set_ylabel('%');axs[0].legend(fontsize=9)
for xx,yy in [(2023,35),(2024,36),(2024,37)]:axs[0].annotate(str(yy),(xx,yy),xytext=(4,5),textcoords='offset points')
axs[1].errorbar([2023,2024,2025],[26,28,30],yerr=[1,1,1],fmt='o-',capsize=8,color=blue);axs[1].set_title('AirTAC：大陆气动份额自估');axs[1].set_xticks([2023,2024,2025]);axs[1].set_ylim(0,45);axs[1].set_ylabel('%')
for xx,lo in [(2023,25),(2024,27),(2025,29)]:axs[1].annotate(f'{lo}–{lo+2}%',(xx,lo+1),xytext=(-15,13),textcoords='offset points')
axs[2].bar([2022,2023,2024,2025],[38.1,36.5,34.5,33.3],color=gray);axs[2].set_title('Festo：集团收入（非份额）');axs[2].set_xticks([2022,2023,2024,2025]);axs[2].set_ylabel('亿欧元');axs[2].set_ylim(0,45)
for xx,v in zip([2022,2023,2024,2025],[38.1,36.5,34.5,33.3]):axs[2].text(xx,v+.5,str(v),ha='center',fontsize=9)
for ax in axs:ax.grid(axis='y',alpha=.15)
fig.tight_layout();share_chart=svg(fig,'05_competition_history_v5')
share_html='<h3>5D｜份额与近年变化：各自分母内比较</h3>'+share_chart+'<p class="note">SMC为2025-11披露的2023／2024自估；AirTAC来自对应年度年报。中国＋香港与大陆范围不同，不能相加或计算两家转移。AirTAC 2023分子是否剔除滑轨未明确。Festo集团收入下降不能直接换算份额流失。'+evidence_link('shares')+' · '+evidence_link('airtac-dated','AirTAC逐年份额')+' · '+evidence_link('investment-findings','Festo收入来源')+'</p>'
chiller_html='<h3>5E｜高端半导体：Chiller独立看</h3>'+ct(['证据','对SMC的含义','不能推出'],[
['Chiller收入：528亿→609亿日元；截至2025／2026年3月财年','增长15.3%；最新占集团7.23%，贡献当年集团增收约16.1%','609亿包含一般工业，不能除以纯半导体温控TAM计算份额；未披露产品利润率'],
['Intel／Micron官方销售确认；AMAT客户认可','支持既有客户基础与高可靠性业务韧性','缺客户内连续份额，仍不能量化证实高端没有显著丢份额'],
['GST 2026-08：Intel常规冷媒chiller准备验证；TSMC电制冷验证中','按客户×产品×验证阶段跟踪竞争','验证不等于量产订单，也不等于替换SMC'],
['京仪2025披露14nm逻辑／192层存储部分工艺量产','中国厂商不能一概归为低端或停留在送样','未证明从SMC转单、最先进制程或国际OEM直接采购']])+'<p class="note">'+evidence_link('pm-conclusions','Chiller规模及中国厂商边界')+' · '+evidence_link('korea-chiller','专业温控厂与验证进度')+'</p>'
expanded_comp=product_html+customer_html+region_html+share_html+chiller_html
cards.append(card(5,'三家公司：产品、客户、地区与份额',[ '● 核心气动存在真实重叠；SMC高端优势须按chiller、真空及流体等具体产品判断。','● 中国通用件承压与当地利润改善可以并存；AirTAC扩张不等于SMC高端全面失守。','△ 高端客户基础获支持，连续份额仍缺；Festo重组是潜在机会，尚非已兑现增量。'],expanded_comp,'以上沿用已核研究；未披露份额不填低，产品覆盖不充当市场份额，客户历史配置不充当当前订单。',evidence_link('pm-conclusions','完整研究及原始来源')))

evidence='''<div class="evidence"><div><h3>● 支持核心业务韧性</h3><p>2024/11：SMC称中国半导体／医疗价格压力相对温和。</p><p>2025/05：AMAT客户内相关份额约六成自估；产品分母未定义。</p><p>2026/08：跨国客户溢价采用、部分客户回流；未单列半导体。</p></div><div><h3>△ 限制与反证</h3><p>2023：光伏部分气缸确有份额损失，不能写成所有业务都稳固。</p><p>缺少高端同产品／同客户份额序列；不能量化确认“没有显著流失”。</p><p>chiller行业有专业对手；增长不等于夺份额或高利润。</p></div></div><div class="flow"><b>Festo德国拟减员1,300人</b><span>→</span><b>SMC 2026/05称可能带来机会<br><small>当时未计入计划</small></b><span>→</span><b>尚待客户转单兑现<br><small>8月欧洲仍克制提价争份额</small></b></div>'''
s1='https://contents.xj-storage.jp/xcontents/AS00674b/8ead6bdc/d33f/4ce5/af0e/497f2810ff97/20241118115701686s.pdf#page=25';s2='https://contents.xj-storage.jp/xcontents/AS00674b/74f8bcda/5362/4245/924b/7c336663dfd0/20260817134629536s.pdf#page=28'
cards.append(card(6,'投资论点：守住高可靠性客户，争取Festo调整带来的增量',['● 基准判断：高可靠性核心业务有韧性；“高端主战场无显著失份额”获定性支持，尚非量化证实。','● Festo调整提供潜在份额机会；没有足够证据计入已兑现的份额或利润增量。'],evidence,'若核心客户同产品采购比例持续下滑，或竞争者获得具名关键平台量产替代订单，应下修判断。客户留存与定价表述主要来自SMC，非独立份额调查。',f'<a href="{s1}">2024竞争分层</a> · <a href="{s2}">2026客户留存</a> · <a href="https://press.festo.com/en/node/5205">Festo调整公告</a> · <a href="../official_products_20260914/SMC_竞争研究_v14_PM统一结论_20260914.html">完整证据</a>'))
css='''*{box-sizing:border-box}body{margin:0;background:#eef2f6;color:#142537;font:16px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}header{max-width:1120px;margin:auto;padding:32px 34px 16px}h1{font-size:30px;margin:4px 0 10px}header p{color:#536579;margin:6px 0}.wrap{max-width:1120px;margin:auto;padding:0 20px 40px}article{background:white;border:1px solid #dce4ed;border-radius:12px;padding:24px 30px;margin:20px 0;break-after:page}.num{color:#64778b;font-size:12px;letter-spacing:2px}h2{font-size:23px;margin:8px 0 14px}.thesis{border-left:4px solid #2264ac;padding:8px 15px;background:#f3f7fb;font-size:15px;line-height:1.6}.chart{margin:18px 0 8px}.historyplot svg{max-height:none!important}.historyplot{margin:24px 0}.chart svg{display:block;width:100%;height:auto;max-height:355px}p.note,footer{font-size:11px;line-height:1.55;color:#5b6b7d}footer a{color:#2264ac}table{border-collapse:collapse;width:100%;font-size:13px;line-height:1.5}td,th{padding:13px 12px;border:1px solid #dce4ed;text-align:left}th{background:#173b61;color:white}td:first-child{font-weight:600;width:19%}.high{background:#e6f3ed;color:#086b52}.evidence{display:grid;grid-template-columns:1fr 1fr;gap:18px}.evidence>div{padding:15px 20px;background:#edf5f2;border-radius:8px}.evidence>div+div{background:#fff3e9}.evidence h3{font-size:16px;margin:4px 0 12px}.evidence p{font-size:14px;line-height:1.6}.flow{display:flex;gap:15px;align-items:center;justify-content:space-between;padding:22px 10px;text-align:center;color:#245481}.flow b{background:#edf2f8;padding:15px;font-size:14px;border-radius:8px}small{font-size:11px;font-weight:400}@media(max-width:700px){article{padding:18px 14px}.wrap{padding:0 8px}.thesis{font-size:13px}.chart{overflow-x:auto}table{min-width:760px}.evidence{grid-template-columns:1fr}.flow{flex-direction:column}h2{font-size:20px}}@media print{@page{size:A4 landscape;margin:10mm}body{background:white}header{padding:0 15px}header h1{font-size:22px}header p{font-size:11px}.wrap{padding:0;max-width:none}article{border:0;margin:0;padding:12px 20px;min-height:175mm}.chart svg{max-height:105mm}h2{font-size:20px}.thesis{font-size:13px}a{text-decoration:none;color:inherit}article:last-child{break-after:auto}}'''
html='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SMC｜PM六个判断</title><style>'+css+'details.region-detail{margin:20px 0}summary{cursor:pointer;font-weight:700;padding:10px 0}.regional{width:100%;font-size:13px;border-collapse:collapse;white-space:nowrap}.regional td{text-align:right}.regional th,.regional td{padding:8px;border-bottom:1px solid #dfe6ee}.regional th{text-align:left}.regional tr:last-child{background:#eef4fa;font-weight:700}.product-gallery{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}.product-gallery figure{margin:0;padding:12px;border:1px solid #dfe6ee;border-radius:10px}.product-gallery img{width:100%;height:140px;object-fit:contain}.product-gallery figcaption{font-size:12px;text-align:center}.competition{width:100%;border-collapse:collapse;font-size:13px;line-height:1.65}.competition th,.competition td{padding:10px;border-bottom:1px solid #dfe6ee;text-align:left;vertical-align:top}.competition th{background:#eef4fa}h3{margin-top:30px}@media(max-width:650px){.product-gallery{grid-template-columns:repeat(2,1fr)}.competition{min-width:800px}}</style><header><div class="num">INVESTMENT EVIDENCE / 2026.09.14</div><h1>SMC：增长、利润修复与竞争韧性</h1><p>历史图表增强版｜六个判断，每项结论不超过三行；● 支持　⊖ 证伪过强说法　△ 限制／待证</p><p>截至2026年4–6月财报；行情截至9月11日。金额默认亿日元。独立精简版，不替代完整研究。</p></header><main class="wrap">'+''.join(cards)+'</main></html>'
(O/'SMC_PM_六个判断_v5_竞争展开_20260914.html').write_text(html)
assert len(cards)==6;assert abs(sum(vals)-295.30)<.01
(O/'delivery_checks_v5.json').write_text(json.dumps({'cards':6,'category_coverage':covered/2709.87,'category_total':covered,'semi_yoy_pct':semigrowth,'semi_increment_share_pct':semicontrib,'op_bridge_sum':sum(vals),'latest_payout_pct':ret.payout_ratio.iloc[-1],'sources':[str(summary),str(R/'earnings_review/近5Q_七行业长表_v2.csv')],'scope':'All charts from existing verified research; no new forecasts; qualitative product coverage not market shares'},ensure_ascii=False,indent=2))
print(O/'SMC_PM_六个判断_v5_竞争展开_20260914.html');print('coverage',covered/2709.87,'semi',semi,semigrowth,semicontrib)
