2026-09-14 更新：e-Stat家庭及CPI、单身年度/季度已取回并核验，研究完成。以[家庭出租车支出与企业预算验证](家庭出租车支出与企业预算验证.md)及对应图表/CSV为准。以下为此前重启检查点，未完成事项和权限状态已过时。

2026-09-14 研究续做点

用户要求使用现有e-Stat接口和民间统计检验出租车家庭预算是否停滞，尤其剔除通胀、确认因公报销不属于消费支出。不要预设结论。

已找到接口 research/macro/estat_loader.py，_app_id()从环境/根.env读取，不打印密钥。新增estat_probe.py安全请求元数据，JSON保存sources/。

已获取sources/estat_meta_0004023601.json：家計調査2025分类月度，含历史1985—2026July。taxi cat01=070100070，消费支出=001100000；cat02四类需读全，04=二人以上勤劳家庭，area全国00000、东京区部13003。先按全国/东京及全部/勤劳家庭筛选，不全表下载800万行。

sources/estat_catalog.csv含单身、总家庭、年收入分组等表：总家庭季度0004023611、年度0004023612，单身季度0004023613、年度0004023614。

已下载官方长期月度CSV三件：sources/kakei_000040270649.csv(2015—19)、650(2020—24)、651(2025—2026July)。来源https://www.e-stat.go.jp/stat-search/file-download?fileKind=1&statInfId=000040270651（其余换id），cp932。第4行列标题，第8列品目，第9列起月度，当前全国二人以上家庭，出租车年度code2025为736（旧分类可能717，需要看实际）。2025Jan-Dec：315,286,410,369,345,367,401,451,395,356,365,389。2026Jan-Jul：356,301,365,358,439,389,487。名义值初看上涨，不能硬说预算不增。须计算相同月份、R12、2019对比，并配CPI。

CPI可用表0003427113（尚未请求核验元数据），taxi7060（需元数据确认），总合亦取。二手提示July2026出租车CPI123.8/2020base、yoy9%，2025annual114.0，但绝不能未回源作为结论。API现在因沙箱经常DNS失败；用户打算yolo重启。已成功ps/footprint诊断LM Studio Node20GB并用户关掉，与研究无关。

消费定义：官方家計分類将立替金列089“実支出以外の支払のその他”，戻り金列049；https://www.e-stat.go.jp/classifications/terms/70/02/D22 是2015分类。需核验2025分类细则及报销逻辑，不能用家計消費状況調査冒充家計調査。家計簿单身指导https://www.stat.go.jp/data/kakei/pdf/form4.pdf有代垫需注明以及返回收入。另一调查家計消費状況調査https://www.stat.go.jp/data/joukyou/pdf/kinyu.pdf明确出差交通住宿不统计，但不同调查。

民间可查JCB消費NOW taxi微观分类；个人卡可能包含企业报销，不能等同家庭自费。Concur/汇计软件有预算调查但尚未找到出租车支出实绩序列。官方机关季度出租车执行数可补案例，不能代替企业总体：财务省https://www.mof.go.jp/about_mof/mof_budget/release/taxi/index.html、内阁https://www.cao.go.jp/yosan/koukai.html、消费者厅https://www.caa.go.jp/policies/budget/procurement_plan/expenditure_001/。

当前已向用户确认本机codex --help及resume --help支持--dangerously-bypass-approvals-and-sandbox；告知退出当前CLI后在当前目录codex resume --dangerously-bypass-approvals-and-sandbox，选择本对话。不要改全局配置/自行解除沙箱。
